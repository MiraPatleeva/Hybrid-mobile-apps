
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    // Cordova is now initialized. Have fun!

    console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);
   // document.getElementById('deviceready').classList.add('ready');

    var element = document.getElementById('deviceProperties');
    element.innerHTML = 'VERSION '+ device.version + ' PLATFORM '+ device.platform;

    var btn = document.getElementById('btn');
    btn.addEventListener('click',(e)=>{
      ons.modifier.add(btn,'large')
    })

    document.addEventListener('show', function(event) {
        ons.ready(function() {	
        if (event.target.matches('#Tab3')) { 
       
       window.addEventListener("batterystatus", example, false);

        function example (status) {
        var range = document.getElementById('range');
        range.value = status.level; 
        if(status.level < 30){
            ons.notification.toast('Battery low:' + status.level, { timeout: 2000 });
        }
    }
        }
        });
        });
        


}
